import fitz
import json
from pathlib import Path


def extract_with_pymupdf(pdf_path):
    doc = fitz.open(pdf_path)
    pages = []
    for page_num, page in enumerate(doc, start=1):
        text = page.get_text("text")
        pages.append({"page": page_num, "text": text})
    doc.close()
    return pages


def extract_paper(pdf_path, out_dir="/home/claude/extracted"):
    pdf_path = Path(pdf_path)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    pages = extract_with_pymupdf(str(pdf_path))
    full_text = "\n\n".join(p["text"] for p in pages)
    out_json = out_dir / f"{pdf_path.stem}.json"
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump({"source": pdf_path.name, "pages": pages}, f, indent=2)
    print(f"Extracted {len(pages)} pages, {len(full_text.split())} words -> {out_json}")
    return pages


if __name__ == "__main__":
    extract_paper("/mnt/user-data/uploads/research_major.pdf")
