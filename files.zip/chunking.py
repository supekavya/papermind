"""
Paper Mind - Chunking Module
------------------------------
Two chunking strategies, same interface, so they can be swapped and compared.
"""

import re
import json


def fixed_size_chunking(pages, chunk_size=150, overlap=30):
    """
    Splits full text into equal-sized word chunks, with overlap so
    sentences aren't harshly cut at chunk boundaries.
    Returns list of dicts: {"text": ..., "page": ..., "strategy": "fixed"}
    """
    chunks = []
    for page in pages:
        words = page["text"].split()
        i = 0
        while i < len(words):
            chunk_words = words[i:i + chunk_size]
            if chunk_words:
                chunks.append({
                    "text": " ".join(chunk_words),
                    "page": page["page"],
                    "section": None,
                    "strategy": "fixed"
                })
            i += (chunk_size - overlap)
    return chunks


SECTION_HEADERS = [
    "abstract", "introduction", "related work", "methods", "methodology",
    "implementation", "experimental results", "results", "discussion",
    "replicability", "datasets", "ethics", "limitations", "conclusion", "references"
]


def section_aware_chunking(pages):
    """
    Splits text along detected section headers (matched against a known
    list of common academic section names). Falls back to page-level
    chunk if no headers detected on that page.
    Returns list of dicts: {"text": ..., "page": ..., "section": ..., "strategy": "section_aware"}
    """
    chunks = []
    current_section = "unknown"
    buffer = []
    buffer_page = None

    def flush():
        if buffer:
            chunks.append({
                "text": " ".join(buffer).strip(),
                "page": buffer_page,
                "section": current_section,
                "strategy": "section_aware"
            })

    for page in pages:
        lines = page["text"].split("\n")
        for line in lines:
            stripped = line.strip()
            lower = stripped.lower().strip(" .0123456789")
            is_header = any(lower == h or lower.startswith(h) for h in SECTION_HEADERS) and len(stripped) < 40

            if is_header:
                flush()
                buffer = []
                current_section = stripped
                buffer_page = page["page"]
            else:
                if stripped:
                    buffer.append(stripped)
                    if buffer_page is None:
                        buffer_page = page["page"]
    flush()
    return [c for c in chunks if len(c["text"]) > 20]  # drop near-empty chunks


if __name__ == "__main__":
    with open("/home/claude/extracted/research_major.json") as f:
        data = json.load(f)
    pages = data["pages"]

    fixed = fixed_size_chunking(pages)
    section = section_aware_chunking(pages)

    print(f"Fixed-size chunking: {len(fixed)} chunks")
    print(f"Section-aware chunking: {len(section)} chunks")
    print("\n--- Sample fixed chunk ---")
    print(fixed[2]["text"][:300])
    print("\n--- Sample section-aware chunk ---")
    for c in section[:5]:
        print(f"[{c['section']}] ({len(c['text'])} chars) — {c['text'][:100]}...")

    with open("/home/claude/extracted/chunks_fixed.json", "w") as f:
        json.dump(fixed, f, indent=2)
    with open("/home/claude/extracted/chunks_section.json", "w") as f:
        json.dump(section, f, indent=2)
    print("\nSaved: chunks_fixed.json, chunks_section.json")
